Portifolio webpage for the HTML-CSS course from Udacity.

https://www.udacity.com/course/intro-to-html-and-css--ud304